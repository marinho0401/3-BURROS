using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using UnoGame.Model;

namespace UnoGame.Converters;

[ValueConversion(typeof(CartaCor), typeof(Brush))]
public class CartaCorToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is CartaCor cor)
        {
            return cor switch
            {
                // Official UNO palette
                CartaCor.Vermelho => new SolidColorBrush(Color.FromRgb(0xE7, 0x4C, 0x3C)),
                CartaCor.Amarelo  => new SolidColorBrush(Color.FromRgb(0xF1, 0xC4, 0x0F)),
                CartaCor.Verde    => new SolidColorBrush(Color.FromRgb(0x2E, 0xCC, 0x71)),
                CartaCor.Azul     => new SolidColorBrush(Color.FromRgb(0x34, 0x98, 0xDB)),
                CartaCor.Especial => new LinearGradientBrush(
                    new GradientStopCollection
                    {
                        new(Color.FromRgb(0xE7, 0x4C, 0x3C), 0),
                        new(Color.FromRgb(0xF1, 0xC4, 0x0F), 0.33),
                        new(Color.FromRgb(0x2E, 0xCC, 0x71), 0.66),
                        new(Color.FromRgb(0x34, 0x98, 0xDB), 1),
                    }, 45),
                _ => Brushes.Gray
            };
        }
        return Brushes.Gray;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}
