using System.IO;
using System.Xml.Serialization;
using UnoGame.Model;

namespace UnoGame.Services;

public class StatisticsService
{
    private static readonly string StatsPath =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                     "UnoGame", "stats.xml");

    private static readonly XmlSerializer _serializer = new(typeof(JogadorStatsList));

    public static List<Jogador> CarregarEstatisticas()
    {
        if (!File.Exists(StatsPath)) return new();
        using var reader = new StreamReader(StatsPath);
        var lista = (JogadorStatsList?)_serializer.Deserialize(reader);
        return lista?.Jogadores ?? new();
    }

    public static void GuardarEstatisticas(IEnumerable<Jogador> jogadores)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(StatsPath)!);
        var lista = new JogadorStatsList { Jogadores = jogadores.ToList() };
        using var writer = new StreamWriter(StatsPath);
        _serializer.Serialize(writer, lista);
    }

    /// <summary>Merge game-ending stats into the persistent store.</summary>
    public static void AtualizarEstatisticas(IEnumerable<Jogador> jogadoresDoJogo)
    {
        var existentes = CarregarEstatisticas();

        foreach (var j in jogadoresDoJogo)
        {
            var existente = existentes.FirstOrDefault(e => e.Nome == j.Nome);
            if (existente == null)
            {
                existentes.Add(j);
            }
            else
            {
                existente.NPartidasJogadas = j.NPartidasJogadas;
                existente.NPartidasGanhas = j.NPartidasGanhas;
                existente.NJogosJogados = j.NJogosJogados;
                existente.NJogosGanhos = j.NJogosGanhos;
            }
        }

        GuardarEstatisticas(existentes);
    }
}

[XmlRoot("Jogadores")]
public class JogadorStatsList
{
    [XmlElement("Jogador")]
    public List<Jogador> Jogadores { get; set; } = new();
}
