using System.IO;
using System.Xml.Serialization;
using UnoGame.Model;

namespace UnoGame.Services;

public class XmlPersistenceService
{
    private static readonly string SavePath =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                     "UnoGame", "save.xml");

    private static readonly XmlSerializer _serializer = new(typeof(Jogo),
        new[] { typeof(JogadorBot) });

    public static void Salvar(Jogo jogo)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(SavePath)!);
        using var writer = new StreamWriter(SavePath);
        _serializer.Serialize(writer, jogo);
    }

    public static Jogo? Carregar()
    {
        if (!File.Exists(SavePath)) return null;
        using var reader = new StreamReader(SavePath);
        return (Jogo?)_serializer.Deserialize(reader);
    }

    public static bool ExisteSave() => File.Exists(SavePath);

    public static void EliminarSave()
    {
        if (File.Exists(SavePath))
            File.Delete(SavePath);
    }
}
