﻿using System.Windows;
using System.Windows.Threading;

namespace UnoGame;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Catch unhandled exceptions and show a message box instead of silent crash
        DispatcherUnhandledException += (s, ex) =>
        {
            MessageBox.Show(
                $"Erro:\n\n{ex.Exception.GetType().Name}\n\n{ex.Exception.Message}\n\n--- Stack ---\n{ex.Exception.StackTrace}",
                "UnoGame — Erro Não Tratado",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            ex.Handled = true;
        };

        AppDomain.CurrentDomain.UnhandledException += (s, ex) =>
        {
            var msg = (ex.ExceptionObject as Exception)?.Message ?? ex.ExceptionObject.ToString();
            MessageBox.Show($"Fatal:\n\n{msg}", "UnoGame — Erro Fatal", MessageBoxButton.OK, MessageBoxImage.Error);
        };
    }
}
