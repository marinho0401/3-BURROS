using System.Xml.Serialization;

namespace UnoGame.Model;

[XmlRoot("Mesa")]
public class Mesa
{
    [XmlElement("Baralho")]
    public Baralho Baralho { get; set; } = new();

    [XmlArray("PilhaDescarte")]
    [XmlArrayItem("Carta")]
    public List<Carta> PilhaDescarte { get; set; } = new();

    /// <summary>The color currently in play (may differ from top card color after a Wild).</summary>
    [XmlAttribute]
    public CartaCor CorAtual { get; set; } = CartaCor.Vermelho;

    [XmlIgnore]
    public Carta? CartaTopo => PilhaDescarte.Count > 0 ? PilhaDescarte[^1] : null;

    /// <summary>Place a card on the discard pile and update CorAtual.</summary>
    public void JogarCarta(Carta carta, CartaCor? corEscolhida = null)
    {
        PilhaDescarte.Add(carta);
        CorAtual = carta.IsCoringa && corEscolhida.HasValue
            ? corEscolhida.Value
            : carta.Cor == CartaCor.Especial ? CorAtual : carta.Cor;
    }

    /// <summary>Draw one card; reshuffles discard if deck is empty.</summary>
    public Carta? ComprarCarta()
    {
        if (Baralho.Count == 0)
            ReembaralharDescarte();

        return Baralho.ComprarCarta();
    }

    /// <summary>Draw multiple cards and return them.</summary>
    public List<Carta> ComprarCartas(int quantidade)
    {
        var cartas = new List<Carta>();
        for (int i = 0; i < quantidade; i++)
        {
            var c = ComprarCarta();
            if (c != null) cartas.Add(c);
        }
        return cartas;
    }

    private void ReembaralharDescarte()
    {
        if (PilhaDescarte.Count <= 1) return;
        // Keep the top card
        var topo = PilhaDescarte[^1];
        PilhaDescarte.RemoveAt(PilhaDescarte.Count - 1);
        Baralho.Cartas.AddRange(PilhaDescarte);
        PilhaDescarte.Clear();
        PilhaDescarte.Add(topo);
        Baralho.Baralhar();
    }

    /// <summary>Setup for a new game: find valid first discard card.</summary>
    public void InicialSetup()
    {
        // Draw first card that is not a Wild or Wild+4
        Carta? primeira = null;
        var temp = new List<Carta>();
        while (Baralho.Count > 0)
        {
            var c = Baralho.ComprarCarta()!;
            if (c.Simbolo != CartaSimbolo.Coringa && c.Simbolo != CartaSimbolo.CoringaMaisQuatro)
            {
                primeira = c;
                break;
            }
            temp.Add(c);
        }
        // Put skipped wilds back
        Baralho.Cartas.AddRange(temp);
        Baralho.Baralhar();

        if (primeira != null)
            PilhaDescarte.Add(primeira);

        CorAtual = CartaTopo?.Cor ?? CartaCor.Vermelho;
    }
}
