namespace UnoGame.Model;

public enum CartaSimbolo
{
    Zero = 0,
    Um = 1,
    Dois = 2,
    Tres = 3,
    Quatro = 4,
    Cinco = 5,
    Seis = 6,
    Sete = 7,
    Oito = 8,
    Nove = 9,
    Inverter,
    Salta,
    MaisDois,
    Coringa,
    CoringaMaisQuatro
}
