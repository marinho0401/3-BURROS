using System.Xml.Serialization;

namespace UnoGame.Model;

[XmlRoot("Jogo")]
public class Jogo
{
    public const int PontuacaoMaxima = 500;
    public const int CartasIniciaisPorJogador = 7;

    [XmlArray("Jogadores")]
    [XmlArrayItem("Jogador", Type = typeof(Jogador))]
    [XmlArrayItem("JogadorBot", Type = typeof(JogadorBot))]
    public List<Jogador> Jogadores { get; set; } = new();

    [XmlElement("Mesa")]
    public Mesa Mesa { get; set; } = new();

    [XmlAttribute]
    public int IndiceAtivo { get; set; }

    [XmlAttribute]
    public bool SentidoClockwise { get; set; } = true;

    /// <summary>Accumulated round scores (key = player name).</summary>
    [XmlArray("Pontuacoes")]
    [XmlArrayItem("Pontuacao")]
    public List<PontuacaoEntry> Pontuacoes { get; set; } = new();

    [XmlIgnore]
    public Jogador JogadorAtivo => Jogadores[IndiceAtivo];

    // ─── Turn Flags ────────────────────────────────────────────────────────────

    /// <summary>When >0 the next player must draw this many cards instead of playing.</summary>
    [XmlAttribute]
    public int CartasAPenalizar { get; set; }

    [XmlAttribute]
    public bool TurnoSaltado { get; set; }

    // ─── Game Setup ────────────────────────────────────────────────────────────

    /// <summary>Initialise a brand-new game with the given players.</summary>
    public static Jogo NovoJogo(List<Jogador> jogadores)
    {
        var jogo = new Jogo();
        jogo.Jogadores = jogadores;

        foreach (var j in jogadores)
        {
            jogo.Pontuacoes.Add(new PontuacaoEntry { Nome = j.Nome, Pontos = 0 });
        }

        jogo.IniciarPartida();
        return jogo;
    }

    /// <summary>Starts a new round (reshuffles deck, deals cards, sets first card).</summary>
    public void IniciarPartida()
    {
        var baralho = Baralho.CriarBaralho();
        Mesa = new Mesa { Baralho = baralho };

        // Clear hands
        foreach (var j in Jogadores)
        {
            j.Cartas.Clear();
            j.GritouUno = false;
        }

        // Deal 7 cards to each player
        foreach (var j in Jogadores)
            j.AdicionarCartas(Mesa.ComprarCartas(CartasIniciaisPorJogador));

        // Place first card
        Mesa.InicialSetup();

        IndiceAtivo = 0;
        SentidoClockwise = true;
        CartasAPenalizar = 0;
        TurnoSaltado = false;

        // Apply effect of the initial face-up card
        AplicarEfeitoCartaInicial();
    }

    // ─── Turn Management ───────────────────────────────────────────────────────

    /// <summary>Advances InjectActive to the next player.</summary>
    public void AvançarTurno(bool saltarProximo = false)
    {
        int passo = SentidoClockwise ? 1 : -1;
        IndiceAtivo = ((IndiceAtivo + passo) + Jogadores.Count) % Jogadores.Count;

        if (saltarProximo)
            IndiceAtivo = ((IndiceAtivo + passo) + Jogadores.Count) % Jogadores.Count;
    }

    /// <summary>Apply effect of the opening card.</summary>
    private void AplicarEfeitoCartaInicial()
    {
        var carta = Mesa.CartaTopo;
        if (carta == null) return;

        switch (carta.Simbolo)
        {
            case CartaSimbolo.Inverter:
                SentidoClockwise = !SentidoClockwise;
                break;
            case CartaSimbolo.Salta:
                AvançarTurno(saltarProximo: true);
                break;
            case CartaSimbolo.MaisDois:
                CartasAPenalizar = 2;
                break;
        }
    }

    /// <summary>
    /// Process a card being played. Returns true if the card was valid.
    /// </summary>
    public bool JogarCarta(Jogador jogador, Carta carta, CartaCor? corEscolhida = null)
    {
        if (!carta.PodeJogarSobre(Mesa.CartaTopo, Mesa.CorAtual))
            return false;

        jogador.RemoverCarta(carta);
        Mesa.JogarCarta(carta, corEscolhida);

        // Apply card effect
        switch (carta.Simbolo)
        {
            case CartaSimbolo.MaisDois:
                CartasAPenalizar += 2;
                AvançarTurno();
                break;
            case CartaSimbolo.CoringaMaisQuatro:
                CartasAPenalizar += 4;
                AvançarTurno();
                break;
            case CartaSimbolo.Salta:
                AvançarTurno(saltarProximo: true);
                break;
            case CartaSimbolo.Inverter:
                SentidoClockwise = !SentidoClockwise;
                if (Jogadores.Count == 2)
                    AvançarTurno(); // In 2-player, Reverse acts as Skip
                else
                    AvançarTurno();
                break;
            default:
                AvançarTurno();
                break;
        }

        return true;
    }

    /// <summary>Force current player to draw pending penalty cards.</summary>
    public List<Carta> AplicarPenalizacao()
    {
        var cartas = Mesa.ComprarCartas(CartasAPenalizar);
        JogadorAtivo.AdicionarCartas(cartas);
        CartasAPenalizar = 0;
        return cartas;
    }

    /// <summary>Current player draws one card (normal draw).</summary>
    public Carta? JogadorCompra()
    {
        var c = Mesa.ComprarCarta();
        if (c != null)
            JogadorAtivo.Cartas.Add(c);
        return c;
    }

    // ─── Scoring & End-of-Round ─────────────────────────────────────────────────

    /// <summary>Check if the active player has won the round.</summary>
    public bool VerificarFimPartida() => JogadorAtivo.Cartas.Count == 0;

    /// <summary>Calculate round points and add to totals. Returns the round winner.</summary>
    public Jogador FinalizarRonda()
    {
        var vencedor = JogadorAtivo;
        vencedor.NPartidasGanhas++;

        int pontosRonda = Jogadores
            .Where(j => j != vencedor)
            .Sum(j => j.PontosNaMao);

        var entrada = Pontuacoes.FirstOrDefault(p => p.Nome == vencedor.Nome);
        if (entrada != null) entrada.Pontos += pontosRonda;

        foreach (var j in Jogadores)
            j.NPartidasJogadas++;

        return vencedor;
    }

    /// <summary>Check if any player has reached the max score.</summary>
    public Jogador? VerificarVencedorJogo()
    {
        var max = Pontuacoes.FirstOrDefault(p => p.Pontos >= PontuacaoMaxima);
        if (max == null) return null;

        var vencedor = Jogadores.First(j => j.Nome == max.Nome);
        return vencedor;
    }

    /// <summary>Finalize the overall game, update statistics.</summary>
    public void FinalizarJogo(Jogador vencedor)
    {
        foreach (var j in Jogadores)
        {
            j.NJogosJogados++;
            if (j == vencedor) j.NJogosGanhos++;
        }
    }

    public int GetPontuacao(string nome)
        => Pontuacoes.FirstOrDefault(p => p.Nome == nome)?.Pontos ?? 0;
}

public class PontuacaoEntry
{
    [XmlAttribute]
    public string Nome { get; set; } = string.Empty;

    [XmlAttribute]
    public int Pontos { get; set; }
}
