using System.Xml.Serialization;

namespace UnoGame.Model;

[XmlRoot("Baralho")]
public class Baralho
{
    [XmlArray("Cartas")]
    [XmlArrayItem("Carta")]
    public List<Carta> Cartas { get; set; } = new();

    private static readonly Random _rng = new();

    /// <summary>Creates a standard 108-card UNO deck.</summary>
    public static Baralho CriarBaralho()
    {
        var baralho = new Baralho();
        int id = 1;

        var cores = new[] { CartaCor.Vermelho, CartaCor.Amarelo, CartaCor.Verde, CartaCor.Azul };

        foreach (var cor in cores)
        {
            // One 0 per color
            baralho.Cartas.Add(new Carta { Id = id++, Cor = cor, Simbolo = CartaSimbolo.Zero, Pontos = 0 });

            // Two of 1-9 + special per color
            for (int i = 0; i < 2; i++)
            {
                for (int n = 1; n <= 9; n++)
                    baralho.Cartas.Add(new Carta { Id = id++, Cor = cor, Simbolo = (CartaSimbolo)n, Pontos = n });

                baralho.Cartas.Add(new Carta { Id = id++, Cor = cor, Simbolo = CartaSimbolo.Inverter, Pontos = 20 });
                baralho.Cartas.Add(new Carta { Id = id++, Cor = cor, Simbolo = CartaSimbolo.Salta, Pontos = 20 });
                baralho.Cartas.Add(new Carta { Id = id++, Cor = cor, Simbolo = CartaSimbolo.MaisDois, Pontos = 20 });
            }
        }

        // 4 Wild + 4 Wild+4
        for (int i = 0; i < 4; i++)
        {
            baralho.Cartas.Add(new Carta { Id = id++, Cor = CartaCor.Especial, Simbolo = CartaSimbolo.Coringa, Pontos = 50 });
            baralho.Cartas.Add(new Carta { Id = id++, Cor = CartaCor.Especial, Simbolo = CartaSimbolo.CoringaMaisQuatro, Pontos = 50 });
        }

        baralho.Baralhar();
        return baralho;
    }

    /// <summary>Fisher-Yates shuffle.</summary>
    public void Baralhar()
    {
        for (int i = Cartas.Count - 1; i > 0; i--)
        {
            int j = _rng.Next(i + 1);
            (Cartas[i], Cartas[j]) = (Cartas[j], Cartas[i]);
        }
    }

    /// <summary>Removes and returns the top card. Returns null if empty.</summary>
    public Carta? ComprarCarta()
    {
        if (Cartas.Count == 0) return null;
        var carta = Cartas[^1];
        Cartas.RemoveAt(Cartas.Count - 1);
        return carta;
    }

    public int Count => Cartas.Count;
}
