using System.Xml.Serialization;

namespace UnoGame.Model;

[XmlRoot("JogadorBot")]
public class JogadorBot : Jogador
{
    private static readonly Random _rng = new();

    // Fixed bot names pool
    public static readonly string[] NomesDisponiveis = { "Alpha", "Beta", "Gamma" };

    public JogadorBot()
    {
        IsHumano = false;
    }

    /// <summary>
    /// Bot AI: choose which card to play.
    /// Strategy: prefer special cards, then numbered; pick wild last.
    /// Returns null if no playable card.
    /// </summary>
    public Carta? EscolherCarta(Carta? cartaTopo, CartaCor corAtual)
    {
        var jogaveis = CartasJogaveis(cartaTopo, corAtual);
        if (jogaveis.Count == 0) return null;

        // Prefer non-wild special cards first, then numbered, then wilds
        var preferencia = jogaveis
            .OrderByDescending(c => c.Pontos)      // specials first
            .ThenBy(c => c.IsCoringa ? 1 : 0)      // wilds last
            .ToList();

        return preferencia[0];
    }

    /// <summary>Bot chooses a color for Wild: the color it has most of.</summary>
    public CartaCor EscolherCor()
    {
        var cores = new[] { CartaCor.Vermelho, CartaCor.Amarelo, CartaCor.Verde, CartaCor.Azul };
        return cores.OrderByDescending(cor => Cartas.Count(c => c.Cor == cor))
                    .FirstOrDefault(CartaCor.Vermelho);
    }
}
