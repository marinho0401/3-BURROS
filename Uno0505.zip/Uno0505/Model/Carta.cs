using System.Xml.Serialization;

namespace UnoGame.Model;

public class Carta
{
    [XmlAttribute]
    public int Id { get; set; }

    [XmlAttribute]
    public CartaSimbolo Simbolo { get; set; }

    [XmlAttribute]
    public CartaCor Cor { get; set; }

    [XmlAttribute]
    public int Pontos { get; set; }

    /// <summary>Returns a display label for the card symbol.</summary>
    [XmlIgnore]
    public string SimboloLabel => Simbolo switch
    {
        CartaSimbolo.Inverter => "⟲",
        CartaSimbolo.Salta => "⊘",
        CartaSimbolo.MaisDois => "+2",
        CartaSimbolo.Coringa => "★",
        CartaSimbolo.CoringaMaisQuatro => "★+4",
        _ => ((int)Simbolo).ToString()
    };

    /// <summary>Returns true if the card is a Wild or Wild+4.</summary>
    [XmlIgnore]
    public bool IsCoringa => Cor == CartaCor.Especial;

    /// <summary>Checks whether this card can be played on top of another card.</summary>
    public bool PodeJogarSobre(Carta? cartaTopo, CartaCor corAtual)
    {
        if (cartaTopo == null) return true;
        if (IsCoringa) return true;
        return Cor == corAtual || Simbolo == cartaTopo.Simbolo;
    }

    public override string ToString() => $"{Cor} {SimboloLabel}";
}
