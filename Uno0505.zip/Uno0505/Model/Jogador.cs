using System.Collections.ObjectModel;
using System.Xml.Serialization;
using CommunityToolkit.Mvvm.ComponentModel;

namespace UnoGame.Model;

[XmlRoot("Jogador")]
[XmlInclude(typeof(JogadorBot))]
public partial class Jogador : ObservableObject
{
    [XmlAttribute]
    public string Nome { get; set; } = string.Empty;

    [XmlAttribute]
    public string FotografiaPath { get; set; } = string.Empty;

    [XmlAttribute]
    public bool IsHumano { get; set; }

    [XmlArray("Cartas")]
    [XmlArrayItem("Carta")]
    public ObservableCollection<Carta> Cartas { get; set; } = new();

    // Statistics
    [XmlAttribute]
    public int NPartidasJogadas { get; set; }

    [XmlAttribute]
    public int NPartidasGanhas { get; set; }

    [XmlAttribute]
    public int NJogosJogados { get; set; }

    [XmlAttribute]
    public int NJogosGanhos { get; set; }

    // Runtime-only flags
    [XmlIgnore]
    public bool GritouUno { get; set; }

    [XmlIgnore]
    public int NumeroCartas => Cartas.Count;

    /// <summary>Returns all playable cards from this hand.</summary>
    public List<Carta> CartasJogaveis(Carta? cartaTopo, CartaCor corAtual)
        => Cartas.Where(c => c.PodeJogarSobre(cartaTopo, corAtual)).ToList();

    /// <summary>Add cards to hand.</summary>
    public void AdicionarCartas(IEnumerable<Carta> cartas)
    {
        foreach (var c in cartas) Cartas.Add(c);
        OnPropertyChanged(nameof(NumeroCartas));
    }

    /// <summary>Remove a card from hand and return it.</summary>
    public bool RemoverCarta(Carta carta)
    {
        bool result = Cartas.Remove(carta);
        OnPropertyChanged(nameof(NumeroCartas));
        return result;
    }

    /// <summary>Points in hand (for scoring losers).</summary>
    public int PontosNaMao => Cartas.Sum(c => c.Pontos);
}
