namespace UnoGame.Model;

public enum CartaCor
{
    Vermelho,
    Amarelo,
    Verde,
    Azul,
    Especial  // for Wild / Wild+4
}
