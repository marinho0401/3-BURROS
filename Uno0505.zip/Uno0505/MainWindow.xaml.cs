﻿using System.Windows;
using UnoGame.ViewModel;

namespace UnoGame;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
