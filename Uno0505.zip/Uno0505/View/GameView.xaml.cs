using System.Windows.Controls;

namespace UnoGame.View;

public partial class GameView : UserControl
{
    public GameView()
    {
        InitializeComponent();
    }
}
