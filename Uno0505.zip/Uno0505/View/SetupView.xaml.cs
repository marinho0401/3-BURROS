using System.Windows.Controls;

namespace UnoGame.View;

public partial class SetupView : UserControl
{
    public SetupView() => InitializeComponent();
}
