using System.Windows.Controls;

namespace UnoGame.View;

public partial class MenuView : UserControl
{
    public MenuView() => InitializeComponent();
}
