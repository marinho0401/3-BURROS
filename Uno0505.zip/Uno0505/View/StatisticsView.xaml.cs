using System.Windows.Controls;

namespace UnoGame.View;

public partial class StatisticsView : UserControl
{
    public StatisticsView() => InitializeComponent();
}
