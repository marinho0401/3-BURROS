using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Windows;
using UnoGame.Services;

namespace UnoGame.ViewModel;

public partial class MenuViewModel : BaseViewModel
{
    private readonly MainViewModel _main;

    public bool ExisteSave => XmlPersistenceService.ExisteSave();

    public MenuViewModel(MainViewModel main) => _main = main;

    [RelayCommand]
    private void NovoJogo() => _main.NavigateToSetup();

    [RelayCommand]
    private void RetomarJogo()
    {
        var jogo = XmlPersistenceService.Carregar();
        if (jogo != null)
            _main.NavigateToGame(jogo);
    }

    [RelayCommand]
    private void Estatisticas() => _main.NavigateToStats();

    [RelayCommand]
    private void Sair() => Application.Current.Shutdown();
}
