using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using UnoGame.Model;
using System.Collections.ObjectModel;

namespace UnoGame.ViewModel;

public partial class SetupViewModel : BaseViewModel
{
    private readonly MainViewModel _main;

    [ObservableProperty]
    private int _numeroDeBots = 1;

    public ObservableCollection<int> OpcoesBot { get; } = new() { 1, 2, 3 };
    public string NomeHumano => Environment.UserName;

    public SetupViewModel(MainViewModel main) => _main = main;

    [RelayCommand]
    private void Iniciar()
    {
        var nomeHumano = Environment.UserName;

        var jogadores = new List<Jogador>
        {
            new Jogador { Nome = nomeHumano, IsHumano = true }
        };

        for (int i = 0; i < NumeroDeBots; i++)
        {
            jogadores.Add(new JogadorBot
            {
                Nome = JogadorBot.NomesDisponiveis[i]
            });
        }

        var jogo = Jogo.NovoJogo(jogadores);
        _main.NavigateToGame(jogo);
    }

    [RelayCommand]
    private void Voltar() => _main.NavigateToMenu();
}
