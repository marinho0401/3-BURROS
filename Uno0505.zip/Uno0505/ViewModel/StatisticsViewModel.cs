using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using UnoGame.Model;
using UnoGame.Services;

namespace UnoGame.ViewModel;

public partial class StatisticsViewModel : BaseViewModel
{
    private readonly MainViewModel _main;

    public ObservableCollection<Jogador> Jogadores { get; } = new();

    public StatisticsViewModel(MainViewModel main)
    {
        _main = main;
        CarregarDados();
    }

    private void CarregarDados()
    {
        Jogadores.Clear();
        foreach (var j in StatisticsService.CarregarEstatisticas())
            Jogadores.Add(j);
    }

    [RelayCommand]
    private void Voltar() => _main.NavigateToMenu();
}
