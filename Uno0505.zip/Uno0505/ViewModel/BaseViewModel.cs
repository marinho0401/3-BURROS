using CommunityToolkit.Mvvm.ComponentModel;

namespace UnoGame.ViewModel;

public abstract class BaseViewModel : ObservableObject
{
}
