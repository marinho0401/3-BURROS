using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using UnoGame.Model;
using UnoGame.Services;

namespace UnoGame.ViewModel;

public partial class GameViewModel : BaseViewModel
{
    private readonly MainViewModel _main;
    private Jogo _jogo;
    private DispatcherTimer _botTimer;
    private Carta? _cartaWildPendente;

    // ─── Observable Properties ─────────────────────────────────────────────

    [ObservableProperty] private Jogador _jogadorHumano;
    [ObservableProperty] private ObservableCollection<JogadorBotVM> _bots = new();
    [ObservableProperty] private bool _isClockwise = true;
    [ObservableProperty] private string _posicaoAtiva = "Bottom";

    // Individual bot slots for the 3×3 grid (null when that slot is empty)
    [ObservableProperty] private JogadorBotVM? _bot1; // Left
    [ObservableProperty] private JogadorBotVM? _bot2; // Top
    [ObservableProperty] private JogadorBotVM? _bot3; // Right

    [ObservableProperty] private bool _bot1Visivel;
    [ObservableProperty] private bool _bot2Visivel;
    [ObservableProperty] private bool _bot3Visivel;

    [ObservableProperty] private Carta? _cartaTopo;
    [ObservableProperty] private CartaCor _corAtual;
    [ObservableProperty] private bool _isTurnoHumano;
    [ObservableProperty] private bool _mostrarSeletorCor;
    [ObservableProperty] private string _mensagem = string.Empty;
    [ObservableProperty] private bool _mostrarMensagem;
    [ObservableProperty] private ObservableCollection<Carta> _cartasJogaveis = new();
    [ObservableProperty] private ObservableCollection<Carta> _cartasHumano = new();
    [ObservableProperty] private bool _temPenalizacao;
    [ObservableProperty] private int _penalizacaoAtual;
    [ObservableProperty] private bool _mostrarUnoButton;
    [ObservableProperty] private bool _podeGritarUno;
    [ObservableProperty] private bool _jogoTerminado;
    [ObservableProperty] private string _mensagemFim = string.Empty;

    // ─── Constructor ────────────────────────────────────────────────────────

    public GameViewModel(MainViewModel main, Jogo jogo)
    {
        _main = main;
        _jogo = jogo;
        _jogadorHumano = jogo.Jogadores.First(j => j.IsHumano);

        _botTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _botTimer.Tick += BotTimer_Tick;

        AtualizarEstado();
    }

    // ─── State Sync ─────────────────────────────────────────────────────────

    private void AtualizarEstado()
    {
        IsClockwise = _jogo.SentidoClockwise;
        CartaTopo = _jogo.Mesa.CartaTopo;
        CorAtual = _jogo.Mesa.CorAtual;
        TemPenalizacao = _jogo.CartasAPenalizar > 0;
        PenalizacaoAtual = _jogo.CartasAPenalizar;

        // Sync the human hand into the observable collection so the View updates
        CartasHumano.Clear();
        foreach (var c in JogadorHumano.Cartas)
            CartasHumano.Add(c);

        // Refresh bot collection (generic, for scores panel)
        Bots.Clear();
        var botJogadores = _jogo.Jogadores.Where(j => !j.IsHumano).ToList();
        foreach (var j in botJogadores)
            Bots.Add(new JogadorBotVM(j, _jogo.JogadorAtivo == j));

        // Map bots to fixed grid slots to guarantee perfectly fluid Clockwise flow!
        Bot1 = null; Bot2 = null; Bot3 = null;

        if (botJogadores.Count == 1)
        {
            Bot2 = new JogadorBotVM(botJogadores[0], _jogo.JogadorAtivo == botJogadores[0]); // Top
        }
        else if (botJogadores.Count == 2)
        {
            Bot1 = new JogadorBotVM(botJogadores[0], _jogo.JogadorAtivo == botJogadores[0]); // Left
            Bot3 = new JogadorBotVM(botJogadores[1], _jogo.JogadorAtivo == botJogadores[1]); // Right
        }
        else if (botJogadores.Count >= 3)
        {
            Bot1 = new JogadorBotVM(botJogadores[0], _jogo.JogadorAtivo == botJogadores[0]); // Left
            Bot2 = new JogadorBotVM(botJogadores[1], _jogo.JogadorAtivo == botJogadores[1]); // Top
            Bot3 = new JogadorBotVM(botJogadores[2], _jogo.JogadorAtivo == botJogadores[2]); // Right
        }

        Bot2Visivel = Bot2 != null;
        Bot1Visivel = Bot1 != null;
        Bot3Visivel = Bot3 != null;

        IsTurnoHumano = _jogo.JogadorAtivo.IsHumano;

        if (_jogo.JogadorAtivo.IsHumano)
            PosicaoAtiva = "Bottom";
        else if (Bot1 != null && _jogo.JogadorAtivo == Bot1.Jogador)
            PosicaoAtiva = "Left";
        else if (Bot2 != null && _jogo.JogadorAtivo == Bot2.Jogador)
            PosicaoAtiva = "Top";
        else if (Bot3 != null && _jogo.JogadorAtivo == Bot3.Jogador)
            PosicaoAtiva = "Right";

        // Update playable cards for human
        CartasJogaveis.Clear();
        if (IsTurnoHumano && !TemPenalizacao)
        {
            foreach (var c in JogadorHumano.CartasJogaveis(_jogo.Mesa.CartaTopo, _jogo.Mesa.CorAtual))
                CartasJogaveis.Add(c);
        }

        // Show UNO button when it's human's turn and has 2 cards and hasn't called yet
        MostrarUnoButton = IsTurnoHumano
            && JogadorHumano.Cartas.Count == 2
            && !JogadorHumano.GritouUno;
        PodeGritarUno = MostrarUnoButton;

        OnPropertyChanged(nameof(JogadorHumano));

        if (!IsTurnoHumano && !JogoTerminado)
            IniciarTurnoBots();
    }

    // ─── Human Commands ─────────────────────────────────────────────────────

    [RelayCommand]
    private void JogarCarta(Carta carta)
    {
        if (!IsTurnoHumano || JogoTerminado) return;

        // Cannot play a card while a draw penalty (+2/+4) is pending — must draw first
        if (TemPenalizacao)
        {
            ExibirMensagem($"⚠️ Tens de comprar {PenalizacaoAtual} carta(s) de penalização primeiro!");
            return;
        }

        // Check UNO penalty: hand has 2 cards and player didn't call UNO
        if (JogadorHumano.Cartas.Count == 2 && !JogadorHumano.GritouUno)
        {
            // Penalize: draw 2 cards
            var penalidade = _jogo.Mesa.ComprarCartas(2);
            JogadorHumano.AdicionarCartas(penalidade);
            ExibirMensagem($"😬 {JogadorHumano.Nome} esqueceu-se do UNO! +2 cartas de penalização.");
            AtualizarEstado();
            return;
        }

        // Wild cards: prompt color first
        if (carta.IsCoringa)
        {
            _cartaWildPendente = carta;
            MostrarSeletorCor = true;
            return;
        }

        ExecutarJogadaHumano(carta, null);
    }

    [RelayCommand]
    private void EscolherCor(string corStr)
    {
        if (!Enum.TryParse<CartaCor>(corStr, out var cor)) return;
        MostrarSeletorCor = false;

        if (_cartaWildPendente != null)
            ExecutarJogadaHumano(_cartaWildPendente, cor);

        _cartaWildPendente = null;
    }

    private void ExecutarJogadaHumano(Carta carta, CartaCor? cor)
    {
        JogadorHumano.GritouUno = false;
        _jogo.JogarCarta(JogadorHumano, carta, cor);

        if (carta.Simbolo == UnoGame.Model.CartaSimbolo.Inverter)
            IsClockwise = !IsClockwise;

        if (_jogo.VerificarFimPartida())
        {
            ProcessarFimRonda();
            return;
        }

        AtualizarEstado();
    }

    [RelayCommand]
    private void ComprarCarta()
    {
        if (!IsTurnoHumano || JogoTerminado) return;

        if (TemPenalizacao)
        {
            var cartas = _jogo.AplicarPenalizacao();
            ExibirMensagem($"Comprou {cartas.Count} carta(s) de penalização.");
            _jogo.AvançarTurno();
        }
        else
        {
            var c = _jogo.JogadorCompra();
            if (c != null)
            {
                ExibirMensagem($"Comprou: {c}");
                _jogo.AvançarTurno();
            }
        }

        AtualizarEstado();
    }

    [RelayCommand]
    private void GritarUno()
    {
        if (!IsTurnoHumano) return;
        JogadorHumano.GritouUno = true;
        ExibirMensagem($"🔴 UNO! {JogadorHumano.Nome} gritou UNO!");
        MostrarUnoButton = false;
    }

    [RelayCommand]
    private void Suspender()
    {
        _botTimer.Stop();
        XmlPersistenceService.Salvar(_jogo);
        StatisticsService.AtualizarEstatisticas(_jogo.Jogadores);
        ExibirMensagem("Jogo guardado com sucesso.");
        Task.Delay(1500).ContinueWith(_ =>
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
                _main.NavigateToMenu()));
    }

    [RelayCommand]
    private void VoltarMenu()
    {
        _botTimer.Stop();
        _main.NavigateToMenu();
    }

    // ─── Bot Logic ──────────────────────────────────────────────────────────

    private void IniciarTurnoBots()
    {
        if (!_botTimer.IsEnabled)
            _botTimer.Start();
    }

    private void BotTimer_Tick(object? sender, EventArgs e)
    {
        _botTimer.Stop();

        if (JogoTerminado) return;
        if (_jogo.JogadorAtivo.IsHumano) return;

        var bot = (JogadorBot)_jogo.JogadorAtivo;

        if (TemPenalizacao)
        {
            // Bot must draw penalty cards
            var cartas = _jogo.AplicarPenalizacao();
            ExibirMensagem($"🃏 {bot.Nome} comprou {cartas.Count} carta(s) de penalização.");
            _jogo.AvançarTurno();
        }
        else
        {
            var carta = bot.EscolherCarta(_jogo.Mesa.CartaTopo, _jogo.Mesa.CorAtual);

            if (carta == null)
            {
                // No playable card: draw one
                _jogo.JogadorCompra();
                ExibirMensagem($"🃏 {bot.Nome} comprou uma carta.");
                _jogo.AvançarTurno();
            }
            else
            {
                // UNO call: bot calls UNO before playing penultimate card
                // Must check BEFORE removing the card (still has 2 in hand)
                if (bot.Cartas.Count == 2)
                {
                    bot.GritouUno = true;
                    ExibirMensagem($"🔴 {bot.Nome}: UNO!");
                    // Short artificial pause — we're already inside the 2s tick so no extra delay needed
                }

                CartaCor? cor = carta.IsCoringa ? bot.EscolherCor() : null;
                string jogadaMsg = $"🤖 {bot.Nome} jogou {carta}" + (cor.HasValue ? $" → escolheu {cor}" : "");
                ExibirMensagem(jogadaMsg);
                _jogo.JogarCarta(bot, carta, cor);

                if (carta.Simbolo == UnoGame.Model.CartaSimbolo.Inverter)
                    IsClockwise = !IsClockwise;
            }
        }

        if (_jogo.VerificarFimPartida())
        {
            ProcessarFimRonda();
            return;
        }

        AtualizarEstado();
    }

    // ─── End of Round ────────────────────────────────────────────────────────

    private void ProcessarFimRonda()
    {
        var vencedorRonda = _jogo.FinalizarRonda();
        var vencedorJogo = _jogo.VerificarVencedorJogo();

        // Always persist statistics after every round
        StatisticsService.AtualizarEstatisticas(_jogo.Jogadores);

        if (vencedorJogo != null)
        {
            _jogo.FinalizarJogo(vencedorJogo);
            // Update again to capture NJogosGanhos
            StatisticsService.AtualizarEstatisticas(_jogo.Jogadores);
            XmlPersistenceService.EliminarSave();

            JogoTerminado = true;
            MensagemFim = $"🏆 {vencedorJogo.Nome} venceu o jogo com {_jogo.GetPontuacao(vencedorJogo.Nome)} pontos!";
        }
        else
        {
            var pontos = _jogo.GetPontuacao(vencedorRonda.Nome);
            ExibirMensagem($"🎉 {vencedorRonda.Nome} venceu a partida! (+{pontos} pts acumulados)");
            Task.Delay(2500).ContinueWith(_ =>
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    _jogo.IniciarPartida();
                    AtualizarEstado();
                }));
        }

        AtualizarEstado();
    }

    // ─── Helper ─────────────────────────────────────────────────────────────

    private async void ExibirMensagem(string msg)
    {
        Mensagem = msg;
        MostrarMensagem = true;
        await Task.Delay(2500);
        MostrarMensagem = false;
    }

    // Expose scores for binding
    public string GetPontuacao(string nome) => _jogo.GetPontuacao(nome).ToString();
}

/// <summary>Wraps a bot Jogador for display in the game view (active highlighting).</summary>
public class JogadorBotVM
{
    public Jogador Jogador { get; }
    public bool IsAtivo { get; }
    public JogadorBotVM(Jogador jogador, bool isAtivo)
    {
        Jogador = jogador;
        IsAtivo = isAtivo;
    }
}
