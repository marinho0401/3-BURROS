using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using UnoGame.Services;

namespace UnoGame.ViewModel;

public partial class MainViewModel : BaseViewModel
{
    [ObservableProperty]
    private BaseViewModel _currentView;

    public MainViewModel()
    {
        _currentView = new MenuViewModel(this);
    }

    public void NavigateTo(BaseViewModel vm) => CurrentView = vm;

    public void NavigateToMenu() => NavigateTo(new MenuViewModel(this));
    public void NavigateToSetup() => NavigateTo(new SetupViewModel(this));
    public void NavigateToStats() => NavigateTo(new StatisticsViewModel(this));

    public void NavigateToGame(UnoGame.Model.Jogo jogo)
        => NavigateTo(new GameViewModel(this, jogo));
}
